function [lifeconsumed]=CycleCounter(soc)

DoD = [0 5 10 20 30 40 50 60 70 80 90 100];  % Energy Swing [%]
NoC = [1e7 5.8e5 1.7e5 5.05e4 2.3e4 1.1e4 6.1e3 4e3 3e3 2.5e3 2.1e3 1.8e3]*2; %*6/1.8;
DoDnew = [0.5:0.5:100];
NoCnew = interp1(DoD,NoC,DoDnew,'pchip','extrap');
DoD = DoDnew;
NoC = NoCnew;
% figure(5); clf
% semilogy(DoD,NoC,'b*')
% ylabel('Number of cycles')
% xlabel('Depth Of Discharge [%]')
% grid

[numberof,depth]=RFofSOC(soc);
depth=2*depth; % Counts amplitudes, not peak-to-peak
figure(1), clf

bar(depth,numberof);
xlabel('DoD [%]')
title('# of cycles')
grid

lifeconsumed=0;
for i=1:length(numberof)
    lifeconsumed = lifeconsumed + numberof(i)/interp1(DoD,NoC,depth(i),'linear','extrap');
end

